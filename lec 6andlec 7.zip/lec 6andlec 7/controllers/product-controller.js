const ProductModel = require('../models/product');
const Category = require('../models/type');


exports.getProducts = (req, res, next) => {
    ProductModel
    .find()
    .populate('categoryId')
    .then(products => {
        console.log('products', products);
        res.render('list-products', {
            pageTitle: "My Store - List Products",
            products: products
        });
    });
}

exports.getAddProducts = (req, res, next) => {
    Category
    .find()
    .then(categories => {
        res.render('add-product', {
            pageTitle: "My Store - Add Products",
            categories: categories
        })
    });
}

exports.postProducts = (req, res, next) => {
    const product = new ProductModel({
        title: req.body.name,
        price: +req.body.price,
        imageUrl: '',
        categoryId: req.body.categoryId
    });
    product.save().then(addedProduct => {
        res.redirect('/shopping/list-products');
    });
}



exports.getShowProducts = (req,res,next) => {

    ProductModel
    .find()
    .then(products => {
        res.render('products', {
            pageTitle: "My Store - show Products",
            products: products
        })
    });


}



exports.getEditProduct = (req, res, next) => {
    const editMode = req.query.edit;
    if (!editMode) {
      return res.redirect('/');
    }
    const prodId = req.params.productId;
    ProductModel.findById(prodId)
      // Product.findById(prodId)
      .then(product => {
        if (!product) {
          return res.redirect('/');
        }
        res.render('admin/edit-product', {
          pageTitle: 'Edit Product',
          path: '/admin/edit-product',
          editing: editMode,
          product: product
        });
      })
      .catch(err => console.log(err));
  };